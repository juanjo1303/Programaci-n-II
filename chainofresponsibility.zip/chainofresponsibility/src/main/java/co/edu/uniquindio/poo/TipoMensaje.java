package co.edu.uniquindio.poo;

public enum TipoMensaje {
    CORREOELECTRONICO,
    SMS,
    MENSAJEVOZ,
}
